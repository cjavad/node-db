This is a fork of [node-json-db](https://github.com/Belphemur/node-json-db/blob/master/LICENSE) Copyright (c) 2014 Antoine Aflalo all rights reserved
